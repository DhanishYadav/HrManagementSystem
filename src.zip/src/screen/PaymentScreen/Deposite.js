import React, { useState, useEffect } from 'react';
import { View, ImageBackground, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Card, Title, Paragraph, Snackbar, Searchbar,Text} from 'react-native-paper';
import Loader from "../constant/Loader";
const ReportTab = ({ navigation }) => {
  const [show, setShow] = useState(false);
  const [snackBarText, setSnackBarText] = useState('');
  const [visibleSnackBar, setVisibleSnackBar] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredData, setFilteredData] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const onShowSnackBar = () => setVisibleSnackBar(true);
  const onDismissSnackBar = () => setVisibleSnackBar(false);
  const data = [
    { "name": "Dhanish yadav", "Amount": "5000", "Datee": "11/10/2023", "TrasID": "675837g7648732@%#$","time":"10:10AM"},
    { "name": "Mohit Singh", "Amount": "51000", "Datee": "1/10/2023", "TrasID": "iuryhg7648732@%#$" ,"time":"6:10PM"},
    { "name": "Manish Maurya", "Amount": "2000", "Datee": "12/10/2023", "TrasID": "duyeiyhg7648732@%#$","time":"2:40AM"},
    { "name": "Manish  Yadav", "Amount": "12000", "Datee": "14/10/2023", "TrasID": "iudyuqiyhg7648732@%#$","time":"08:10PM"},
    { "name": "Sandeep Yadav", "Amount": "13000", "Datee": "21/10/2023", "TrasID": "i37467yhg7648732@%#$","time":"11:10AM"},
    { "name": "Trishna Pandey", "Amount": "15000", "Datee": "01/10/2023", "TrasID": "iuryhg7648732@%#$","time":"6:10AM"},
    { "name": "Dhanish Tiwari", "Amount": "245000", "Datee": "12/10/2023", "TrasID": "65ghyryhg7648732@%#$","time":"12:50pM"},
    { "name": "Dhanish Pandey", "Amount": "355000", "Datee": "13/10/2023", "TrasID": "64586hgbnnm@%#$","time":"1:10AM"},
    { "name": "Shivam Shukla", "Amount": "35000", "Datee": "16/10/2023", "TrasID": "ishdbbkjh7648732@%#$","time":"11:10PM"},
  ];  
  const handleSearch = (query) => {
    setSearchQuery(query);
    setSelectedStudent(null); 
    const filtered = data.filter((item) =>
      item.name.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredData(filtered);
  };
  const renderCardItem = ({ item }) => (
    <TouchableOpacity onPress={() => setSelectedStudent(item)}>
      <Card style={styles.card1}>
        <Card.Content>
          <Title style={styles.heading}>Student Name: {item.name}</Title>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );
  return (
    <>
      <ImageBackground
        source={require('../../asserts/back.png')}
        style={styles.backgroundImage}
      >
      <Text style={{fontSize:23,fontWeight:"bold",color:"white",alignSelf:"center",marginTop:30}}>Abhishek Singh</Text>
        <View style={styles.mainContainer}>
          <Searchbar
            placeholder="Search By Client Name"
            onChangeText={handleSearch}
            value={searchQuery}
            style={styles.searchInput}
          />
          {selectedStudent ? (
            <Card style={styles.card}>
              <Card.Content>
                <Title style={[styles.heading, { fontSize: 20 }]}> Name: {selectedStudent.name}</Title>
                <Title style={styles.heading}> Deposit Amount : {selectedStudent.Amount}</Title>
                <Paragraph style={styles.date}> Date: {selectedStudent.Datee}{selectedStudent.time}</Paragraph>
                <Paragraph style={styles.date}> Time : {selectedStudent.time}</Paragraph>
                <Paragraph style={styles.timing}> TrasID: {selectedStudent.TrasID}</Paragraph>
              </Card.Content>
            </Card>
          ) : (
            <FlatList
              data={searchQuery ? filteredData : data}
              keyExtractor={(item) => item.name}
              renderItem={renderCardItem}
            />
          )}
          <Snackbar
            visible={visibleSnackBar}
            onDismiss={() => setVisibleSnackBar(false)}
            style={styles.snackBar}
            action={{
              label: 'Dismiss',
              onPress: () => {
                setVisibleSnackBar(false);
              },
            }}
          >
            {snackBarText}
          </Snackbar>
        </View>
      </ImageBackground>
    </>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: 'white',
    marginTop:60,
    margin: 10,
  },
  container: {
    flex: 1,
    marginTop: 48,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  card: {
    marginTop: 8,
    marginHorizontal: 10,
    backgroundColor:"white"
  },
  card1: {
    marginTop: 8,
    marginHorizontal: 10,
    backgroundColor:"white",
    height:65,
  },
  heading: {
    fontSize:15,
    fontWeight: 'bold',
    color: 'gray',
  },
  row: {
    flexDirection: 'row',
    marginTop: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'gray',
  },
  timing: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'gray',
  },
  searchInput: {
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 20,
    margin: 8,
    backgroundColor: "white"
  },
  status: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  suggestionItem: {
    padding: 10,
    borderColor: 'grey',
  },
});

export default ReportTab;
