
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Login from '../components/Login';
import DashBoard from '../components/DashBoard';
import AdminLogin from '../components/AdminLogin';
import AdminScreen from '../components/AdminScreen';
import Deposit from '../PaymentScreen/Deposite';
import Transaction from '../PaymentScreen/Transaction';
import WithdrawalScreen from '../PaymentScreen/WithdrawalScreen';
import Refund from '../PaymentScreen/Refund';
const Stack = createNativeStackNavigator();
const MyStack = () => {
     return (
          <Stack.Navigator initialRouteName='Login'>
               <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
               <Stack.Screen name="Dashboard" component={DashBoard} options={{ headerShown: false }} />
               <Stack.Screen name="AdminLogin" component={AdminLogin} options={{ headerShown: false }} />
               <Stack.Screen name="AdminScreen" component={AdminScreen} options={{ headerShown: false }} />
               <Stack.Screen name="Deposit" component={Deposit} options={{ headerShown: false }} />
               <Stack.Screen name="Transaction" component={Transaction} options={{ headerShown: false }} />
               <Stack.Screen name="WithdrawalScreen" component={WithdrawalScreen} options={{ headerShown: false }} />
               <Stack.Screen name="Refund" component={Refund} options={{ headerShown: false }} />
          </Stack.Navigator>
     );
}
export default MyStack;