export default {
    primary: '#5d6fe2',
    accent: '#5d6fe2',
    buttonSuccessColor: '#ffffff',
    buttonDangerColor: 'red',
    inputTextColor: '#808080',
    bg: "#f06d01"
}