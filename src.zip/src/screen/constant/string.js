export default {
    app_name: "Attendance",
    url:"http://ats.mandiup.com/api/API",
};