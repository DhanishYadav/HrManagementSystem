import React from 'react';
import axios from 'axios';

const RazorPay = (props) => {
  const { name, amount, currency, email, contact } = props;
  const openRazorPay = () => {
    var options = {
      description: 'Credits towards consultation',
      image: 'https://i.imgur.com/3g7nmJC.png',
      currency: currency,
      key: 'YOUR_RAZORPAY_KEY', // Replace with your Razorpay API key
      amount: amount.toString(), // Make sure it's a string
      name: name,
      prefill: {
        email: email,
        contact: contact,
        name: name,
      },
      theme: { color: '#003990' },
    };
    RazorpayCheckout.open(options).then((data) => {
      // handle success
      alert(`Success: ${data.razorpay_payment_id}`);
      // Send the transaction details to your server for storage
      const transactionData = {
        transactionId: data.razorpay_payment_id,
        name: name,
        amount: amount,
        currency: currency,
        email: email,
        contact: contact,
        status: 'success', // Add a status for successful transactions
      };
      // Make an API call to your server to store the transaction details using Axios
      axios.post('YOUR_API_ENDPOINT', transactionData)
        .then((response) => {
          // Handle the response from your server if needed
        })
        .catch((error) => {
          // Handle API call errors
          console.error('Error storing transaction details:', error);
        });
    }).catch((error) => {
      // handle failure
      alert(`Error: ${error.code} | ${error.description}`);
      // Send the failed transaction details to your server for storage
      const failedTransactionData = {
        name: name,
        amount: amount,
        currency: currency,
        email: email,
        contact: contact,
        status: 'failed', // Add a status for failed transactions
      };
      // Make an API call to your server to store the failed transaction details using Axios
      axios.post('YOUR_API_ENDPOINT_FOR_FAILED', failedTransactionData)
        .then((response) => {
          // Handle the response from your server if needed
        })
        .catch((error) => {
          // Handle API call errors
          console.error('Error storing failed transaction details:', error);
        });
    });
  };
  return (
    <button onClick={openRazorPay}>Pay with Razorpay</button>
  );
};
export default RazorPay;
