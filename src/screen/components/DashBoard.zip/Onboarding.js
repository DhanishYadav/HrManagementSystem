import { useNavigation } from '@react-navigation/native';
import { Text, View, StyleSheet, ImageBackground, StatusBar, TouchableOpacity } from 'react-native';
export default function App() {
     const navigation = useNavigation();
     const navigationHandle = () => {
          navigation.navigate("Dashboard");
     };
     return (
          <View style={styles.container}>
               <StatusBar
                    backgroundColor="#f2612b" />
               <ImageBackground source={require("../../asserts/12Images.jpg")} resizeMode="cover" style={styles.image}>
                    <View style={styles.card}>
                         <Text style={styles.cardTitle}>Flore Farms</Text>
                         <Text style={styles.carddescriptions}>Specializing in multiple varieties of tulips, this farm is most popular in the spring</Text>
                         <TouchableOpacity style={styles.buttn} onPress={navigationHandle}>
                              <Text style={styles.btntxt}>Browse flowers</Text>
                         </TouchableOpacity>
                    </View>
               </ImageBackground>
          </View>
     );
}

const styles = StyleSheet.create({
     container: {
          flex: 1,
     },
     image: {
          flex: 1,
     },
     icon: {
          height: 30,
          width: 20,
          alignSelf: 'flex-end'
     },
     drawer: {
          height: 30,
          width: 30,
          alignSelf: 'flex-start'
     },
     headTitle: {
          fontSize: 20,
          fontWeight: 'bold',
          alignSelf: 'center'
     },
     card: {
          backgroundColor: 'white',
          borderRadius: 10,
          padding: 30,
          alignItems: 'center',
          position: "absolute",
          left: 10,
          bottom: 20,
     },
     cardTitle: {
          fontSize: 30,
          fontWeight: '800',
          alignSelf: 'center',
          color: "gray"
     },
     carddescriptions: {
          fontSize: 20,
          fontWeight: '500',
          alignSelf: 'center',
          marginTop: 9,
          color: "gray"
     },
     buttn: {
          backgroundColor: 'black',
          height: 40,
          alignItems: 'center',
          width: '100%',
          borderRadius: 10,
          marginTop: 10,
          justifyContent: "center"
     },
     btntxt: {
          color: 'white',
          alignSelf: 'center',
          fontSize: 16, fontWeight: "700"
     }
});
