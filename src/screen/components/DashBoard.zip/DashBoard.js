import { useNavigation } from '@react-navigation/native';
import { Text, View, StyleSheet, StatusBar, Image, TouchableOpacity, FlatList } from 'react-native';

export default function App() {
  const navigation = useNavigation();

  const navigationHandle = (item) => {
    navigation.navigate("ImagesScreen", { itemId: item.id });
  };

  const data = [
    {
      id: 1, money: "$1.00/ea", txt: "hellebore", img: require('../../asserts/h1.jpg')
    },
    {
      id: 2, money: "$1.40/ea", txt: "Daisy", img: require('../../asserts/da1.png')
    },
    {
      id: 3, money: "$2.00/ea", txt: "Iris Reticulate", img: require('../../asserts/iri.jpg')
    },
    {
      id: 4, money: "$3.00/ea", txt: "Tulip", img: require('../../asserts/tulip.jpg')
    },
    {
      id: 5, money: "$1.50/ea", txt: "Rose", img: require('../../asserts/rose.jpg')
    },
    {
      id: 6, money: "$4.00/ea", txt: "Lotus", img: require('../../asserts/lotus.jpg')
    }
  ];

  const renderitem = ({ item }) => (
    <View style={styles.itemCard}>
      <TouchableOpacity onPress={() => navigationHandle(item)}>
        <Image source={typeof item.img === 'string' ? { uri: item.img } : item.img} style={{ height: 170, width: 180, borderRadius: 10 }} />
        <Text style={{ color: 'black', fontSize: 20, fontWeight: '700', marginTop: 8 }}>{item.txt}</Text>
        <Text style={{ color: 'black', fontSize: 20, fontWeight: '700', marginTop: 4 }}>{item.money}</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar
        backgroundColor="white" />
      <Text style={styles.cardTitle}>Flore Farms</Text>
      <FlatList
        style={{ marginHorizontal: 10, marginTop: 10 }}
        data={data}
        renderItem={renderitem}
        keyExtractor={item => item.id.toString()}
        numColumns={2}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemCard: {
    marginHorizontal: 4,
    marginTop: 20,
    paddingBottom: 10
  },
  cardTitle: {
    fontSize: 30,
    fontWeight: '800',
    color: "gray",
    paddingLeft: 20
  },
});
