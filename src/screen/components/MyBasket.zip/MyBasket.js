import { useNavigation } from '@react-navigation/native';
import { Text, View, StyleSheet, StatusBar, Image, TouchableOpacity, FlatList } from 'react-native';
export default function App() {
  const navigation = useNavigation();
  const navigationHandle = (item) => {
    navigation.navigate("ImagesScreen", { itemId: item.id });
  };
  const data = [
    {
      id: 1, money: "$1.00/ea", txt: "hellebore", img: require('../../asserts/h1.jpg')
    },
    {
      id: 2, money: "$1.40/ea", txt: "Daisy", img: require('../../asserts/da1.png')
    },
    {
      id: 3, money: "$2.00/ea", txt: "Iris Reticulate", img: require('../../asserts/iri.jpg')
    },
    {
      id: 4, money: "$3.00/ea", txt: "Tulip", img: require('../../asserts/tulip.jpg')
    },
    {
      id: 5, money: "$1.50/ea", txt: "Rose", img: require('../../asserts/rose.jpg')
    },
    {
      id: 6, money: "$4.00/ea", txt: "Lotus", img: require('../../asserts/lotus.jpg')
    }
  ];
  const renderitem = ({ item }) => (
    <View style={styles.itemCard}>
      <TouchableOpacity onPress={() => navigationHandle(item)} style={styles.itemContainer}>
        <Image source={typeof item.img === 'string' ? { uri: item.img } : item.img} style={styles.image} />
        <View style={styles.textContainer}>
          <Text style={{ color: 'black', fontSize: 20, fontWeight: '700', }}>{item.txt}</Text>
          <Text style={{ color: 'black', fontSize: 20, fontWeight: '700', }}>{item.money}</Text>
          <Text style={[styles.textStyle, {
            fontSize: 22, paddingLeft: 0, borderWidth: 1, borderColor: "black", width: 100, height: 40,
            borderRadius: 10, backgroundColor: "white",
            marginTop: 40, textAlign: "center", paddingTop: 4, color: "black"
          }]}> -  1  +</Text>
        </View>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar
        backgroundColor="white" />
      <Text style={styles.cardTitle}>Flore Farms</Text>
      <FlatList
        style={{ marginHorizontal: 10, marginTop: 8 }}
        data={data}
        renderItem={renderitem}
        keyExtractor={item => item.id.toString()}
      // numColumns={2}
      />
      <View style={{
        flexDirection: "row", marginHorizontal: 8,
        justifyContent: "space-between", height: 1, backgroundColor: "black",
        marginVertical: 20
      }}>
      </View>
      <View style={{ flexDirection: "row", marginHorizontal: 11, justifyContent: "space-between", height: 50, }}>
        <Text style={{ fontSize: "gray", fontWeight: "bold", fontSize: 20, color: "gray" }}>SubTotal</Text>
        <Text style={{ fontSize: "gray", fontWeight: "bold", fontSize: 22, color: "black" }}>$26.99</Text>
      </View>
      <View style={{
        borderWidth: 1, borderColor: "white", height: 50, alignItems: "center",
        borderRadius: 10, justifyContent: "center",
        backgroundColor: "black", marginHorizontal: 11, marginBottom: 20
      }}>
        <TouchableOpacity onPress={navigationHandle}>
          <Text style={[styles.textStyle, { fontSize: 20, paddingLeft: 0, color: "white" }]}>Schedule A Pick-Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 30,
    fontWeight: '800',
    color: "gray",
    paddingLeft: 20
  },
  itemCard: {
    marginHorizontal: 4,
    marginTop: 20,
    paddingBottom: 10,
  },
  itemContainer: {
    flexDirection: "row",

  },
  image: {
    height: 170,
    width: 180,
    borderRadius: 10,
  },
  textContainer: {
    flexDirection: "column",
    marginLeft: 30,
  },
});
